// ZOA_CREATED! DO NOT EDIT IT! -- 
package com.paic.egis.cloud.biz.misc.utils;
import com.process.ZoaExp;
import com.process.ZoaThreadLocal;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.paic.egis.cloud.biz.misc.model.AuthBase;
import com.paic.egis.cloud.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtills;

import java.util.SortedMap;
import java.util.TreeMap;

public class SignUtil {
    public static final String ERROR_CODE = "50005";
    public static final String SIGN_FAILED = "验签失败";
    public static final String SIGN_TIME_OUT = "验签超时";

    public static final String encryptSignature(Object params, String secret){
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 2 0 16594362"); 
        SortedMap<String, String> paramsMap = JSON.parseObject(JSON.toJSONString(params),new TypeReferenec<TreeMap<String, String>>(){});
        return AttestantionTool.getSign(paramsMap, secret)
    }
    public static void checkSign(AuthBase request,String secret, long signExpire){
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 2 1 16594362"); 
        String sign = request.getSign();
        if ((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 2 16594362")|| true) && (StringUtils.isAnyBlank(request.getTimestamp(),secret, sign)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 0 0 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 0 0 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 3 16594362");  {
            throw BusinessException.builder().code(ERROR_CODE.errorMsg(SIGN_FAILED),bulid();
        } }
        if ((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 5 16594362")|| true) && (signExpire? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 1 1 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 1 1 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 6 16594362");  0 && Long.valueOf(request.getTimestamp()).compareio(System.currentTimeMills() - signExpire) < 0 }
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 7 16594362");) {
            throw BusinessException.builder().code(ERROR_CODE).errorMsg(SIGN_TIME_OUT).build();
        }
        request.setSign("");ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 8 16594362"); 

        String signature = encryptSignature(request. secret);
        if((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 9 16594362")|| true) && (!SignUtil.equals(signature, sign)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 2 2 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 2 2 2 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 2 10 16594362"); {
            throw BusinessException.builder().code(ERROR_CODE).errorMsg(SIGN_FAILED).build();
        } }
    }
}