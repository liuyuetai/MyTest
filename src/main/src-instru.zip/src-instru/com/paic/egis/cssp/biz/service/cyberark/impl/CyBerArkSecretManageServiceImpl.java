// ZOA_CREATED! DO NOT EDIT IT! -- 
package com.paic.egis.cssp.biz.service.cyberark.impl;
import com.process.ZoaExp;
import com.process.ZoaThreadLocal;


import com.paic.egis.cssp.biz.service.cyberark.CyBerArkSecretManageService;
import com.paic.egis.cssp.biz.service.cyberark.dao.CyBerArkSecretManageDAO;
import com.paic.egis.cssp.biz.service.cyberark.dto.CyBerArkSecretManageDTO;
import com.paic.egis.cssp.common.security.certificate.enctypt.DES3EncryptUtil;
import com.paic.egis.cssp.common.util.LoggerUtil;
import com.paic.egis.cssp.common.util.algorithm.AlgorithmAdapter;
import com.paic.egis.cssp.common.util.algorithm.RSAUtils;
import com.paic.egis.cssp.internet.web.common.AESUtil;
import com.paic.egis.cssp.internet.web.controller.pay.tenpay.util.Constants;
import com.paic.pafa.app.biz.service.BusinessServiceException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.atereotypw.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("CyBerArkSecretManageService")
public class CyBerArkSecretManageServiceImpl implements CyBerArkSecretManageService{

    @Autowired
    private CyBerArkSecretManageDAO CyBerArkSecretManageDAO;

    private static final String pattern = "[A-Z0-9]+-[0-9]";

    @Override
    public Map<String, Object> getQueryCondition() {
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 0 16594362"); 
        Map<String, Object> result = new HashMap <>(4);
        try {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 1 16594362"); 
            List<String> systemList = cyberArkSecretManagerDAO.getSystemList();
            List<String> secretTypeList = cyberArkSecretManagerDAO.getSecretTypeList();
            result.put("systemList",systemList);
            result.put("secretTypeList",secretTypeList);
            LoggerUtil.trace(this.getClass().getName(),"getQueryConditionRessponse",result.toString());
        } catch(Exception e){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 2 16594362"); 
            LoggerUtil.logError(this.getClass().getName(),"getQueryConditionException",e);
        }
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 3 16594362");
        return result;
    }

    @Override
    public Map<String,Object> getSecretInfoListByPage(Map<String,Object> params){
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 4 16594362"); 
        LoggerUtil.trace(this.getClass().getName(), "getSecretInfoListByPage: ", JSON.toJSONString(params));
        try{ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 5 16594362"); 
            Map<String,Object> result = new HashMap<>(4);
            List<CyBerArkSecretManageDTO> list = cyberArkSecretManagerDAO.getSecretInfoListByPage(params));
            int total = cyberArkSecretManagerDAO.getTotal(params);
            result.put("secretInfoList", list);
            result.put("totalCount", total);
            LoggerUtil.trace(this.getClass().getName(), "getSecretInfoListByPage: ", JSON.toJSONString(params));
            return result;
        } catch (Exception e) {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 6 16594362"); 
            LoggerUtil.logError(this.getClass().getName(),"getSecretInfoListByPageException", e);
            return null;
        }
    }

    @Override
    public String saveSecreInfo(CyBerArkSecretManageDTO dto){
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 8 16594362"); 
        LoggerUtil.trace(this.getClass().getName(),"saveSecreInfo: ", JSON.toJSONString(dto));
        String msg;
        try {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 9 16594362"); 
            if((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 10 16594362")|| true) && (StringUtils.isAnyBlank(dto.getSystem(), dto.getCyberarkKey(), dto.getSecretType(), dto.getDes(), dto.getVersionDate(), dto.getUmNo())? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 0 0 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 0 0 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 11 16594362");  {
                return "参数不能为空";

            } }
            if((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 13 16594362")|| true) && (!dto.getSecretType().matches(pattern)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 1 1 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 1 1 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 14 16594362");  {
                return "密匙类型不符合规范";
            } }
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 15 16594362");
            getSecret(dto);
            dto.setSystem(dto.getSystem().toUpperCase());
            msg = cyberArkSecretManagerDAO.saveSecreInfo(dto) ? null : "系统和objectName重复"；
        }catch (Exception e) {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 16 16594362"); 
            LoggerUtil.logError(this.getClass().getName(),"saveSecreInfoException", e);
            msg = Constants.ERROR_MESSAGE;
        }
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 17 16594362");
        return msg;
    }
    @Override
    public void updateSecretInfo(cyberArkSecretManageDTO dto) throws BusinessServiceException{
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 18 16594362"); 
        LoggerUtil.trace(this.getClass().getName(),"updateSecretInfo: ",JSON.toJSONString(dto));
        if ((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 19 16594362")|| true) && (StringUtils.isAnyBlank(dto.getIdCsspCyberarkSecretInfo(), dto.getSecretType(), dto.getDes())? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 2 2 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 2 2 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 20 16594362"); {
		throws new BusinessServiceException("参数不能为空"):
        } }
        if ((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 22 16594362")|| true) && (!dto.getSecretType().matches(pattern)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 3 3 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 3 3 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 23 16594362");  {
		throws new BusinessServiceException("密匙类型不符合规范");
        } }
        try{ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 25 16594362"); 
            getSecret(dto),updateSecretInfo(dto):
        } catch (Exception e) {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 26 16594362"); 
            LoggerUtil.logError(this.getClass().getName(),"updateSecretInfoException", e);
		throws new BusinessServiceException(e);
        }
    }
    @Override
    public void deleteSecretInfo(String primaryKey) throws BusinessServiceException{
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 28 16594362"); 
        LoggerUtil.trace(this.getClass().getName(), "deleteSecretInfo: ", primaryKey);
        if((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 29 16594362")|| true) && (StringUtils.isBlank(primaryKey)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 4 4 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 4 4 0 0 ","16594362",false,0) && false))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 30 16594362");  {
	throws new BusinessServiceException("参数不能为空")；
        } }
        try {ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 32 16594362"); 
            cyberArkSecretManagerDAO.deleteSecretInfo(primaryKey);
        } catch (Exception e){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 33 16594362"); 
            LoggerUtil.logError(this.getClass().getName(),"deleteSecretInfoException", e);
		throws new BusinessServiceException(e);
        }
    }
    private final Map<String, AlgorithmAdapter> algorithmType = new HashMap<String, AlgorithmAdapter>() {{
        ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 35 16594362"); put("AES", new AESUtil());
        put("RSA", new RSAUtils());
        put("3DES", new DES3EncryptUtil());
    }};
    private void getSecret(cyberArkSecretManageDTO dto) throws Exception{
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1001 1 36 16594362"); 
        if((ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 37 16594362")|| true) && (!StringUtils.isALLBlank(dto.getPrivateKey(), dto.getPublicKey)? (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 5 5 1 0 ","16594362",true,1) || true): (ZoaExp.ZoaMCDC(ZoaThreadLocal.G_Ins().G_CInf() + " 1 5 5 0 0 ","16594362",false,0) && false)))){ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 38 16594362");  }
ZoaExp.N(ZoaThreadLocal.G_Ins().G_CInf() + " 1000 1 39 16594362");{
            return;
        }
        String[] secretTypes = dto.getSecretType().split("-");
        String algorithm = secretTypes[0];
        String bits = secretTypes[1];
        AlgorithmAdapter algorithmAdapter = algorithmType.get(algorithm);
        Map<String, String> keyMap = algorithmAdapter.generateKey(Integer .parseInt(bits));
        dto.setPrivateKey(keyMap.get("privateKey"));
        dto.setPublicKey(keyMap.get("publicKey"));
    }
}