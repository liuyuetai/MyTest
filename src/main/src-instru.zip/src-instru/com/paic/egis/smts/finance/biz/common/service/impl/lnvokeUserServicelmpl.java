package com.paic.egis.smts.finance.biz.common.service.impl;
import com.paic.egis.cloud.common.rpc.model.Request;
import com.paic.egis.cloud.common.rpc.model.Response;
import com.paic.egis.cloud.user.model.account.AccountInfoRequest;
import com.paic.egis.cloud.user.model.dto.account.AccountInfoDTO;
import com.paic.egis.cloud.user.service.UserInfoTypeResponse;
import com.paic.egis.cloud.user.service.UserService;
import com.paic.egis.smts.finance.biz.common.service.InvokeUserService;
import com.paic.pafa.exceptions.BusinessException;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.utill.ArrayList;
import static com.paic.egis.cloud.user.enums.UserInfoTypeEnum.HFL_USER;

public class lnvokeUserServicelmpl {
    @Component("invokeUserService)
            public class InvokeUserServiceImpl implements InvokeUserService{
            @Autowired
            private UserService userService;
            @Autowired
            private UserAcctService userAcctService;




            @Override
            public UserInfoTypeResponse getUserINfoByUTokenFromUser(String uToken,String sysSpurce) throws BusinessException{
            Response<UserInfoTypeResponse> responseResult = userService.getUserInfoByToken(uToken, sysSource);
            if(!responserResult.isOK()) {
        throw new BusinessException(responseResult.getErrorMsg());
    }
            return responseResult.getPayload();
}
    @Override
    public String getPAByUTokenFromUser(String uToken, String sysSource) throws BusomessException{
        UserInfoTypeResponse userInfo = this.getUserInfoByUTokenFromUser(uToken, sysSource);
        if(HFL_USER.getcode().equals(userInfo.getUserInfoType())) {
            AccountInfoRequest accountInfoRequest = new AccountInfoRequest();
            accountInfoRequest.setIdCsspUser(userInfo.getIdCsspUser());
            Request<AccountInfoRequest> request = new Request<>();
            request.setBusinessObject(accountInfoRequest);
            Response<ArrayList<AccountInfoDTO>>response = userAcctService.getPamaAccountInfo(request);
            ArrayList<AccountInfoDto>payload = response.getPayload();
            return CollecitonUtils.isNotEmpty(payload) ? payload.get(0).getAccountNo() :null;
        }
        return null;
    }
}
